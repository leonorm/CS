package org.example.energy.goal.manager;

import org.apache.felix.ipojo.annotations.Component;
import org.apache.felix.ipojo.annotations.Instantiate;
import org.apache.felix.ipojo.annotations.Provides;
import org.apache.felix.ipojo.annotations.Requires;
import org.example.energy.goal.api.EnergyGoalManagerAdministration;
import org.example.follow.me.api.EnergyGoal;
import org.example.follow.me.api.FollowMeAdministration;
import org.example.follow.me.api.IlluminanceGoal;
import org.example.temperature.api.TemperatureManagerAdministration;

@Component
@Instantiate(name = "energy.goal.manager")
@Provides(specifications = { EnergyGoalManagerAdministration.class })
public class EnergyGoalManagerImpl implements EnergyGoalManagerAdministration {

	/** Field for followMeManager dependency */
	@Requires
	private FollowMeAdministration followMeManager;
	
	@Requires
	private TemperatureManagerAdministration temperatureManager;
	
	
	public void temperatureIsTooHigh(String roomName){
		temperatureManager.temperatureIsTooHigh(roomName);
	}
	 
    public void temperatureIsTooLow(String roomName){
    	temperatureManager.temperatureIsTooLow(roomName);
    }
	
	
	public void setIlluminancePreference(IlluminanceGoal illuminanceGoal) {
		followMeManager.setIlluminancePreference(illuminanceGoal);
	}

	public IlluminanceGoal getIlluminancePreference() {
		return followMeManager.getIlluminancePreference();
	}

	public void setEnergySavingGoal(EnergyGoal energyGoal) {
		followMeManager.setEnergySavingGoal(energyGoal);
	}

	public EnergyGoal getEnergyGoal() {
		return followMeManager.getEnergyGoal();
	}	
	
	
	
	
	
	
	
	
	
	
	

}
