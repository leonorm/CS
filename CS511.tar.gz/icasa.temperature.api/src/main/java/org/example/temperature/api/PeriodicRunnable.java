package org.example.temperature.api;

public interface PeriodicRunnable {

}